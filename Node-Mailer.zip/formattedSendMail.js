const nodemailer = require("nodemailer");
const fs = require("fs");
const { promisify } = require("util");

const readFileAsync = promisify(fs.readFile);

async function sendEmail() {
  // Read the HTML template and image file
  const htmlTemplate = await readFileAsync("template.html", "utf-8");
  const imageAttachment = await readFileAsync("tajjj.jpg");

  // Create a Nodemailer transporter
  const transporter = nodemailer.createTransport({
    service: "gmail",
    auth: {
      user: "nikhilcetpa@gmail.com",
      pass: "qdad sgnk aoeo dhwf",
    },
  });

  // Send email
  const info = await transporter.sendMail({
    from: "nikhilcetpa@gmail.com",
    to: "nikhilsinghal000@gmail.com",
    subject: "Sending FORMATTED Email using Node.js",
    html: htmlTemplate,
    attachments: [
      {
        filename: "image.png",
        content: imageAttachment,
        encoding: "base64",
        cid: "uniqueImageCID", // Referenced in the HTML template
      },
    ],
  });

  console.log("Email sent:", info.messageId);
}

sendEmail();
